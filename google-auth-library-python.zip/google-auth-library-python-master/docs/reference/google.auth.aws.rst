google.auth.aws module
======================

.. automodule:: google.auth.aws
   :members:
   :inherited-members:
   :show-inheritance:
