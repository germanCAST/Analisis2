google.oauth2.id\_token module
==============================

.. automodule:: google.oauth2.id_token
   :members:
   :inherited-members:
   :show-inheritance:
