google.auth.downscoped module
=============================

.. automodule:: google.auth.downscoped
   :members:
   :inherited-members:
   :show-inheritance:
