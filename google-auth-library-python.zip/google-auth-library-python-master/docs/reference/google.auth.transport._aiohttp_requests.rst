google.auth.transport.aiohttp\_requests module
==============================================

.. automodule:: google.auth.transport._aiohttp_requests
   :members:
   :inherited-members:
   :show-inheritance:
