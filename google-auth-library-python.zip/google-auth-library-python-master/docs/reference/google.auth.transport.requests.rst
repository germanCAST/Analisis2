google.auth.transport.requests module
=====================================

.. automodule:: google.auth.transport.requests
   :members:
   :inherited-members:
   :show-inheritance:
