google.oauth2.sts module
========================

.. automodule:: google.oauth2.sts
   :members:
   :inherited-members:
   :show-inheritance:
