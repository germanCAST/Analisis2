google.auth.external\_account module
====================================

.. automodule:: google.auth.external_account
   :members:
   :inherited-members:
   :show-inheritance:
