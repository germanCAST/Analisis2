google.auth.environment\_vars module
====================================

.. automodule:: google.auth.environment_vars
   :members:
   :inherited-members:
   :show-inheritance:
