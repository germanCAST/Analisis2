google.auth.exceptions module
=============================

.. automodule:: google.auth.exceptions
   :members:
   :inherited-members:
   :show-inheritance:
