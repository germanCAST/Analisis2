google.auth.identity\_pool module
=================================

.. automodule:: google.auth.identity_pool
   :members:
   :inherited-members:
   :show-inheritance:
