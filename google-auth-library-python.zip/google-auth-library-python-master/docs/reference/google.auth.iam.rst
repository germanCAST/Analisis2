google.auth.iam module
======================

.. automodule:: google.auth.iam
   :members:
   :inherited-members:
   :show-inheritance:
