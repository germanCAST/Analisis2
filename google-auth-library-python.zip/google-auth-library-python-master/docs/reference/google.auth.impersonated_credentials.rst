google.auth.impersonated\_credentials module
============================================

.. automodule:: google.auth.impersonated_credentials
   :members:
   :inherited-members:
   :show-inheritance:
